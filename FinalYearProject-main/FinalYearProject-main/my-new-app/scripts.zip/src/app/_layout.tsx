// import { Stack } from "expo-router";
// import { AuthProvider } from "../context/Auth";

// export default function RootLayout() {
//   return (
//     <AuthProvider>
//       <Stack>
//         <Stack.Screen name="index" options={{ headerShown: false }} />
//         <Stack.Screen name="home" options={{ title: "Home" }} />
//         <Stack.Screen
//           name="attendance"
//           options={{ title: "Attendance Dashboard" }}
//         />
//       </Stack>
//     </AuthProvider>
//   );
// }

import { Slot } from "expo-router"; // or Stack
import { AuthProvider } from "../context/Auth"; // Adjust import path if needed

export default function RootLayout() {
  return (
    <AuthProvider>
      {/* All screens inside Slot/Stack can now use useAuth() */}
      <Slot /> 
    </AuthProvider>
  );
}